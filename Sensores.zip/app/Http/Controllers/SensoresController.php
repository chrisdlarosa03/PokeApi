<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;

class SensoresController extends Controller
{
    public function getSensoresData(){
        $response = Http::get('https://iotsensor-production-aab2.up.railway.app/sensors');
        $objectResponse = $response->object();
        return view('listaSensores',[
            'sensores'=>$objectResponse
        ]);
    }
}
