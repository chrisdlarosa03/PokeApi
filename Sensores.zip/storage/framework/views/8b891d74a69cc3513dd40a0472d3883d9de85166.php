<?php $__env->startSection('title', 'Tabla de PoleApi'); ?>
<?php $__env->startSection('content'); ?>
            <div class="row text-center fixed-top mt-5 blue red">
                <h2>Tabla PokeApi de <?php echo e($minombre); ?></h2>
            </div>
            <div class="row justify-content-md-center" style="margin-top: 8em">
                <div class="col-md-8">
                    <table class="table table-light table-striped text-center">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Pokemon</th>
                                <th>Accion</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $i = 1;
                            ?>
                            <?php $__currentLoopData = $pokemons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pokemon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($i++); ?></td>
                                <td><?php echo e($pokemon->name); ?></td>
                                <td>
                                    <a href="/mostrarPokemon/<?php echo e($pokemon->name); ?>"><button type="button" class="btn btn-primary"><i class="fa-solid fa-eye"></i></button></a>

                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer', 'texto del footer'); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravels\poke\resources\views/listaPokemons.blade.php ENDPATH**/ ?>