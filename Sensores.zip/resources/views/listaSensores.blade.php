@extends('layout')
@section('title', 'Sensores | INCUBADORA')
@section('content')
    <div class="row text-center fixed-top mt-5 headers">
        <h2>Tabla Sensores</h2>
    </div>
    <div class="row justify-content-md-center" style="margin-top: 8em">
        <div class="col-md-8">
            @php
                $i = 1;
                $nombre = "Nombre-Sensor";
                $tipo = "Tipo-Sensor";
                $data = "Data";
                $string = "Data-String";
                $fechaHora = "Fecha-Hora";
            @endphp
            @foreach ($sensores as $sensor)
                <div class="card text-center">
                    <div class="card-header">
                        {{$sensor->$nombre}}
                    </div>
                    <div class="card-body">
                        <h5 class="card-title">{{$sensor->$string}}<span class="badge badge-secondary">{{$sensor->$tipo}}</span></h5>
                            @if(strpos($sensor->$string, 'Temperatura') !== false)
                                <div class="progress">
                                    <div class="progress-bar bg-warning" role="progressbar" style="width: {{$sensor->$data}}%;" aria-valuenow="{{$sensor->$data}}" aria-valuemin="0" aria-valuemax="50">{{$sensor->$data}}C</div>
                                </div>
                            @endif
                            @if(strpos($sensor->$string, 'Humedad') !== false)
                                <div class="progress">
                                    <div class="progress-bar" role="progressbar" style="width: {{$sensor->$data}}%;" aria-valuenow="{{$sensor->$data}}" aria-valuemin="0" aria-valuemax="100">{{$sensor->$data}}%</div>
                                </div>
                            @endif
                            <br>
                        <a href="#" class="btn btn-primary">Historial</a>
                    </div>
                        <div class="card-footer text-muted">
                            @php
                                $fecha = substr($sensor->$fechaHora, 1, 11);
                                $hora = substr($sensor->$fechaHora, 13, -1);
                            @endphp
                            {{$fecha}}
                            {{$hora}}
                        </div>
                </div>
                <br>
                @endforeach
                    <table class="table table-light table-striped text-center">
                        <thead>
                            <tr>
                                <th>id</th>
                                <th>Nombre de Sensor</th>
                                <th>Tipo de Sensor</th>
                                <th>Datos</th>
                                <th>String</th>
                                <th>Fecha y Hora</th>
                            </tr>
                        </thead>
                        <tbody>
                            @php
                                $i = 1;
                                $nombre = "Nombre-Sensor";
                                $tipo = "Tipo-Sensor";
                                $data = "Data";
                                $string = "Data-String";
                                $fechaHora = "Fecha-Hora";
                            @endphp
                            @foreach ($sensores as $sensor)
                                <tr>
                                    <td>{{$i++}}</td>
                                    <td>{{$sensor->$nombre}}</td>
                                    <td>{{$sensor->$tipo}}</td>
                                    <td>{{$sensor->$data}}</td>
                                    <td>{{$sensor->$string}}</td>
                                    <td>{{$sensor->$fechaHora}}</td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
        </div>
    </div>
@endsection
@section('footer', 'texto del footer')
